import os
import numpy as np

class Resources :
	def __init__(self, renewable):
            self.renewable = renewable 
            
class Mode :
    def __init__(self,jobnr,mode,duration,usedRessources):
        self.jobnr = jobnr
        self.mode = mode
        self.duration = duration
        self.usedRessources = usedRessources    
        
class Job :
    def __init__(self,jobnr, modes, amountModes,amountSuccessors,successors,predecessors):
         self.jobnr = jobnr
         self.modes = modes
         self.amountModes = amountModes
         self.amountSuccessors = amountSuccessors
         self.successors = successors  
         self.predecessors = predecessors     
          
class Problem :
    def __init__(self,amountJobs,timeHorizont,amountAvaibleRessources,avaibleRessources,jobs,delta):
        self.amountJobs = amountJobs
        self.amountAvaibleRessources = amountAvaibleRessources
        self.availableResources = avaibleRessources
        self.jobs = jobs
        self.delta = delta
        self.timeHorizont = timeHorizont
           
def readFileUBO(file):
    data_file_path = os.path.join(os.path.dirname(__file__), file)
    f = open(data_file_path)
    lines = f.readlines()
    n = int(lines[0].split()[0]) + 2
    p = Problem(0,0,0,Resources([]),[],np.array([[0]*n]*n))
    #Anazhl Jobs reele Jobs und unreele Jobs 
    p.amountJobs = n
    #Anzahl erneurbare Ressourcen
    p.amountAvaibleRessources = int(lines[0].split()[1])
    #Jobs definieren und deleta konstruiren
    for i in range(1,p.amountJobs+1):
        job = Job(0,0,0,0,[],set())
        linesplit  = lines[i].split()
        job.jobnr = int (linesplit[0])
        job.modes = int (linesplit[1])
        job.amountSuccessors = int (linesplit[2])
        for j in range(0,job.amountSuccessors):
            job.successors.append(int(linesplit[j+3]))
            js = int(linesplit[j+3])
            delta_ij = linesplit[j+3+job.amountSuccessors][1:-1]
            p.delta[job.jobnr][js] =  int(delta_ij)
        p.jobs.append(job)
    
    #Mode aufbauen
    count_line= p.amountJobs+1
    for i in range(count_line,count_line+p.amountJobs):
                mode = Mode(0,0,0,[])
                linesplit  = lines[i].split()
                mode.jobnr = int (linesplit[0])
                mode.mode = int (linesplit[1])
                mode.duration = int (linesplit[2])
                for j in range(0,p.amountAvaibleRessources):
                    mode.usedRessources.append(int(linesplit[j+3]))
                p.jobs[mode.jobnr].modes = mode
    #Timehorizont abschaetzen timeHorizont = summe(Bearbeitungsdauer)
    for j in p.jobs :
        p.timeHorizont += j.modes.duration
    # Ressourcenkapazitaeten
    count_line += p.amountJobs
    linesplit  = lines[count_line].split()
    for i in range(0, p.amountAvaibleRessources):
          p.availableResources.renewable.append(int(linesplit[i]))
    #Update Job n+2
    p.jobs[p.amountJobs-1].amountSuccessor = 1
    p.jobs[p.amountJobs-1].successors.append(0) 
    p.jobs[p.amountJobs-1].modes.duration = 0
    p.delta[p.amountJobs-1][0] = -p.timeHorizont  #Wenn du das Beispiel psp0.sh test will dann muss hier -6 geschrieben werden
    #Vorgängen von jedem Job j abbilden
    for j in range(0, p.amountJobs):
        for i in range(0,p.amountJobs):
            if j in p.jobs[i].successors:
                p.jobs[j].predecessors.add(i)
    return p
