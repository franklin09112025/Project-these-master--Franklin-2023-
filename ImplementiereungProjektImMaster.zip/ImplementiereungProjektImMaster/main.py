from readInstancePSPLIB import readFilePSPLIB
from readInstanceUBO import readFileUBO
from serielleGenerierungsschema import*
#UBO-Instanzen einlesen
#p = readFileUBO("InstanzenUBO10\\psp0.sch")
#print(f"Schedule von UBO: {serielleSchemaUBO(p)}")
#PSBLIP-Insatnzen einlesen
p = readFilePSPLIB("InstanzenPSPLIB\\j3013_0.sm")
#Gib Schedule aus
print(f"Schedule von PSPLIB: {serielleSchemaPSPLIB(p)}")
print(f"Distanzmatrix: {tripel_AlgorithmusPSPLIB(p)}")