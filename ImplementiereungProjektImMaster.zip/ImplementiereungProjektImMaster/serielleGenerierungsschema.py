from tripelalgorithm import *
import numpy as np

#LST Prioritätsregel
def LST_Regel(C_bar,LS):
    min_LS = np.inf
    index_j = set()
    for h in C_bar:
        if LS[h] < min_LS:
            min_LS = LS[h]
    for i in C_bar :
        if LS[i] == min_LS:
            index_j.add(i)
    j = list(index_j)[0] 
    return j

# Betimme Zeitpunkt t* für Job j 
def minimal_t(p,ES,LS,j,usedRessource) :
    numberOfusedRessources =len(p.jobs[j].modes.usedRessources)
    counter = 0
    found = False
    t = ES[j]
    for  t in range(ES[j] ,p.timeHorizont-p.jobs[j].modes.duration+1):
            for  k in range(0, numberOfusedRessources):
                for tau in range(t, t+p.jobs[j].modes.duration):
                        if  usedRessource[k][tau] + p.jobs[j].modes.usedRessources[k] <= p.availableResources.renewable[k]:
                               counter +=1
            if counter == numberOfusedRessources*p.jobs[j].modes.duration:
                      found = True
                      break
            counter = 0
    if (found == True):
        #Einplanung für alle tau 
        for  k in range(0, numberOfusedRessources):
            for tau in range(t, t+p.jobs[j].modes.duration):
                    usedRessource[k][tau] += p.jobs[j].modes.usedRessources[k]
    return t , usedRessource

#Klassische serielle Generierungsschema
def serielleSchemaPSPLIB(p):
    # Bestimme ES und LS werte mithilfe vom Tripelalgorithmus
    d  = tripel_AlgorithmusPSPLIB(p)
    n = p.amountJobs
    ES = {}
    LS = {}
    for i in range(0,n):
        ES[i] =  d[0][i]
        LS[i] = -d[i][0]
    #Initialisierung  
    C= set()
    C.add(0) 
    S={0:0}
    epsilon = set()
    C_bar = {i  for i in range(1,n)}
    #rSc(k,t)
    usedRessource = dict({k :{ t : 0 for t in range(0,p.timeHorizont+1) } for k in range(0,len(p.availableResources.renewable))})
    pred_node = {i : set() for i in range(0,n)}
    #Aufbau der Voränger jedes Job j
    for j in C_bar:
        for i in range(0,n):
            if j in p.jobs[i].successors: # Update Nach deiner Kommentaren : Jetzt sind noch Jobs betracht , wenn alle Vorgänger in C sind.
                pred_node[j].add(i)
    for alpha in range(1,n):
    #Aufbau epsilon
        for j in C_bar:
            #Pred(j) teilmenge von C
            if   p.jobs[j].predecessors.issubset(C):
                    epsilon.add(j)
        #Wähle Vorgang j mit höchster Priorität
        j = LST_Regel(epsilon,LS)
        #Bestimme ES[j]
        Pred_j = p.jobs[j].predecessors
        ES_max = 0
        for i in Pred_j:  #Update Nach deiner Kommentaren: 
            if ES_max < S[i] + d[i][j]:
                ES_max =  S[i] + d[i][j]
        ES[j] = ES_max
        #Bestimme t* = min_t
        min_t ,usedRessource = minimal_t(p,ES,LS,j,usedRessource) 
        #Plane Vorgang j zum Zeitpunkt t* ein 
        S[j] = min_t
        C_bar.remove(j)
        C.add(j)
        epsilon = set()
    #Sortierung der Startzeitpunkt
    S =dict(sorted(S.items(), key=lambda x: x[1]))  
    return S

#Ressource frei machen , wenn job j ausgeplant wird
def ausplanenRessourcen(p,usedRessource,t,j):
     numberOfusedRessources =len(p.jobs[j].modes.usedRessources)
     for  k in range(0, numberOfusedRessources):
            for tau in range(t, t+p.jobs[j].modes.duration):
                usedRessource[k][tau] -= p.jobs[j].modes.usedRessources[k]
     return usedRessource
 
#Serielle Generierungsschema mit Ausplanung    
def serielleSchemaUBO(p):
    # Bestimme ES und LS werte mithilfe vom Tripelalgorithmus
    V = {i  for i in range(0,p.amountJobs)}
    u = 0
    d  = tripel_AlgorithmusUBO(p)
    print(f"Distanzmatrix:\n{d}")
    n = p.amountJobs
    ES = {}
    LS = {}
    for i in range(0,n):
        ES[i] = d[0][i]
        LS[i] =-d[i][0]
    print(f"ES={ES}")
    print(f"LS={LS}")
    print("---------------------------------")
    #Initialisierung  
    C= set()
    C.add(0) 
    S={0:0}
    epsilon = set()
    #rSc(k,t)
    #p.timeHorizont = 6 #(Nur für Instanz Beispiel psp0.sh)
    usedRessource = dict({k :{ t : 0 for t in range(0,p.timeHorizont+1) } for k in range(0,len(p.availableResources.renewable))})
    pred_node = {i : set() for i in range(0,n)}
    #Aufbau der Voränger jedes Job j
    for j in V-C:
        for i in V:
             if(d[i][j]>0 or (d[i][j]==0 and d[j][i]<0)):
                    pred_node[j].add(i)
    while C != V:
    #Aufbau epsilon
        for j in V-C:
            #Pred(j) teilmenge von C
                if pred_node[j].issubset(C):
                    epsilon.add(j)
        #Wähle Vorgang j mit höchster Priorität
        j = LST_Regel(epsilon,LS)
        #Bestimme t* = min_t
        min_t ,usedRessource = minimal_t(p,ES,LS,j,usedRessource) 
        # ------------------Ausplanung mit t*-LS[j] --------------------------------------------------
        if(min_t >= LS[j]+1):
            u = u +1 
            U = []
            for i in C :
                if LS[j] == S[i] - d[j][i]:
                    U.append(i)
            if 0 in U :
                   return "1 Keine Zulässige Lösung gefunden"
            #Schritt 1. Rechtsverschiebun der Vorgänge i in U
            for i in U :
                ES[i] = S[i] + min_t - LS[j]
                C.remove(i)
                usedRessource = ausplanenRessourcen(p,usedRessource,S[i],i)
                if ES[i] > -d[i][0]:
                   return  "2 Keine Zulässige Lösung gefunden"
            #Schritt 2. Plane alle Vorgänge i mit S_i > min_(h in U ){ S_h} aus 
            min_Sh = np.iinfo(np.int32).max
            for h in U :
                    if S[h] < min_Sh :
                        min_Sh = S[h] 
            C_copy = C.copy()
            for i in C_copy :
                if S[i] >= min_Sh+1:
                    C.remove(i)
                    usedRessource = ausplanenRessourcen(p,usedRessource,S[i],i)
            #Schritt 3. ES-LS Uodate für akke g in V-C
            for h in V-C:
                max_ESi = np.iinfo(np.int32).min
                for i in U:
                    if ES[i] + d[i][h] > max_ESi:
                        max_ESi = ES[i] + d[i][h]        
                    ES[h] = max(d[0][h], max_ESi)
                    LS[h] = -d[h][0]
                    for i in C:
                        ES[h] = max(ES[h], S[i]+d[i][h])
                        LS[h] = min(LS[h], S[i]-d[h][i]) 
           #-----------------------------------------------------------------------------------------
        #Plane j zum Zeitpunkt min_t
        else :
            S[j] = min_t
            C.add(j)
            for h in V-C:
                #Aktualisiere ESh und LSh
                ES[h] = max(ES[h], S[j]+d[j][h])
                LS[h] = min(LS[h], S[j]-d[h][j])
        epsilon = set() 
    #Sortierung der Startzeitpunkten
    S =dict(sorted(S.items(), key=lambda x: x[1])) 
    print(f"Anzahl Ausplanungsschritte: {u}")
    return S
    
            
               