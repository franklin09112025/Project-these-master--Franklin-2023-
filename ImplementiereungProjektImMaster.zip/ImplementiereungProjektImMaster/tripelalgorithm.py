import numpy as np
from readInstancePSPLIB import*
# Tripel Algorithmus
def tripel_AlgorithmusPSPLIB(P) :
    n  = P.amountJobs
    d = np.array([[0]*n]*n,np.int64) #Update nach Kommentare
    p = np.array([[0]*n]*n)
    #Initialisierung
    for i in range(0,n):
        d[i][i] = 0
        p[i][i] = i
        for j in range(0,n):
            if j!=i:
                if j in P.jobs[i].successors:
                    d[i][j] = P.jobs[i].modes.duration
                elif j not in P.jobs[i].successors:
                    d[i][j] = np.iinfo(np.int32).min
                if  d[i][j] > np.iinfo(np.int32).min:
                    p[i][j] = i
                else :
                    p[i][j] = -1
    d[n-1][0] = -P.timeHorizont
    #Hauptschritt
    for v in range(0,n):
        for i in range(0,n):
            if i != v and d[i][v] > np.iinfo(np.int32).min:
                for j in range(0,n):
                     if  j != v and d[i][j] < d[i][v] + d[v][j]:
                         d[i][j] = d[i][v] + d[v][j]
                         p[i][j] = p[v][j]
    return d
def tripel_AlgorithmusUBO(P) :
    n  = P.amountJobs
    d = np.array([[0]*n]*n,np.int64) 
    p = np.array([[0]*n]*n)
    #Initialisierung
    for i in range(0,n):
        d[i][i] = 0
        p[i][i] = i
        for j in range(0,n):
            if j!=i:
                if j in P.jobs[i].successors:
                    d[i][j] = P.delta[i][j]
                elif j not in P.jobs[i].successors:
                    d[i][j] = np.iinfo(np.int32).min
                if  d[i][j] > np.iinfo(np.int32).min:
                    p[i][j] = i
                else :
                    p[i][j] = -1
    #Hauptschritt
    for v in range(0,n):
        for i in range(0,n):
            if i != v and d[i][v] > np.iinfo(np.int32).min:
                for j in range(0,n):
                     if  j != v and d[i][j] < d[i][v] + d[v][j]:
                         d[i][j] = d[i][v] + d[v][j]
                         p[i][j] = p[v][j]
    return d