from enum import Enum

import csv

class GenomeType(Enum):
    RANDOM_VECTOR = 1
    ACTIVITY_LIST = 2

class MutationOperator(Enum):
    RANDOM_RESETTING = 1
    RANDOM_SWAP = 2
    INSERT = 3

class CrossoverOperator(Enum):
    UNIFORM = 1
    ONE_POINT = 2
    PARTIALLY_MAPPED = 3
    

class Config:
    def __init__(self, name, genome_type, num_generations, generation_size, mutation_operator, mutation_rate, crossover_operator, crossover_rate):
        self.name = name
        self.genome_type = genome_type
        self.num_generations = num_generations
        self.generation_size = generation_size
        self.mutation_operator = mutation_operator
        self.mutation_rate = mutation_rate
        self.crossover_operator = crossover_operator
        self.crossover_rate = crossover_rate

    def write_to_csv(self, csv_writer):
        csv_writer.writerow([self.name, self.genome_type, self.num_generations, self.generation_size, self.mutation_operator,str(self.mutation_rate).replace('.',','), self.crossover_operator, str(self.crossover_rate).replace('.',',')])




    
    
