import random
from readInstancePSPLIB import *

class RandomVectorGenome:
    def __init__(self, random_vectors):
        self.random_vectors = random_vectors

    #initialisiert das Genom mit zufaelligen werten
    @classmethod
    def init_randomly(cls, num_jobs):
        random_vectors = []
        #der Projektanfang muss immer an erster Stelle stehen und muss deswegen nicht im Genom kodiert werden
        for i in range(num_jobs-1):
            random_vectors.append(random.random())
        return cls(random_vectors)

    def __str__(self):
        result = "[ "
        for number in self.random_vectors:
            result += str(number)+" "
        result += "]"
        return result

    def get_priorities(self):
      
        number_index_pair = []
        for i in range(len(self.random_vectors)):
            #hier wird der Projektanfang uebersprungen. Er wird am Ende an den Anfang der Prioritaetsliste gesetzt
            number_index_pair.append((self.random_vectors[i],i+1))
        sorted_pairs = sorted(number_index_pair)
        #der Projektanfang wird immer an den Anfang gestellt
        sorted_pairs.insert(0, (0,0))
        return [pair[1] for pair in sorted_pairs]
        
class ActivityListGenome:
    def __init__(self, activities, jobs):
        self.activities = activities
        self.jobs = jobs
        self.fixActivityOrder()

    #stellt sicher, dass keine Aktivitaet vor ihrem Vorgaenger steht
    def fixActivityOrder(self):
        while(True):
            nothingWrong = True
            for i in range(len(self.activities)):
                for j in range(len(self.activities)-1, i,-1):
                    if(self.activities[i] in self.jobs[self.activities[j]].successors):
                        temp = self.activities[i]
                        self.activities[i] = self.activities[j]
                        self.activities[j] = temp
                        nothingWrong = False
                        break
            if(nothingWrong):
                return
           
    
    def __str__(self):
        result = "[ "
        for number in self.activities:
            result += str(number)+" "
        result += "]"
        return result
    
    #initialisiert das Genom mit zufaelligen werten
    @classmethod
    def init_randomly(cls, jobs):
        activities =[]

        #der Projektanfang muss immer an erster Stelle stehen und muss deswegen nicht im Genom kodiert werden
        activitiesLeft = list(range(len(jobs)-1,0,-1))

        while(0 < len(activitiesLeft)):
            randomIndex = random.randint(0,len(activitiesLeft)-1)
            activities.append(activitiesLeft.pop(randomIndex))

        return cls(activities, jobs)

    def get_priorities(self):
        return [0]+self.activities

    

