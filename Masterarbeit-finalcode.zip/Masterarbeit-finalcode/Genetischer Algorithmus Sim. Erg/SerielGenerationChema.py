
def _are_ressources_available(start_time, duration, used_ressources, ressource_availabilities):
    for i in range(len(used_ressources)):
        amount_used = used_ressources[i]
        for availabilties in ressource_availabilities:
            for t in range(start_time, start_time+duration+1):
                 if t >= len(availabilties):
                    print(f"IndexError: t={t}, len(availabilties)={len(availabilties)}")
                    return False
                 if availabilties[t] < amount_used:
                    return False
    return True


def _compute_predecessors(jobnr, jobs):
    predecessors = []
    for job in jobs:
        if jobnr in job.successors:
            predecessors.append(job.jobnr)
    return predecessors

def _compute_epsilon(C,C_Complement, jobs):
    
    Epsilon = []
    for j in C_Complement:
        predecessors = _compute_predecessors(j, jobs)
        if set(predecessors).issubset(C):
            Epsilon.append(j)
    return Epsilon

def seriel_generation_chema(problem, genome):

    #Berechne die maximale Zeit
    max_time = 1
    for job in problem.jobs:
        max_time += job.modes.duration

    #Erstelle fuer jede Ressource eine Liste mit den verfuegbaren Ressourcen zu jedem Zeitpunkt
    ressource_availabilities = []
    for i in range(len(problem.availableResources.renewable)):
        availabilities_over_time = []
        for j in range(problem.timeHorizont + 1):
            availabilities_over_time.append(problem.availableResources.renewable[i])
        ressource_availabilities.append(availabilities_over_time)

    #print("Verfuegbare Ressourcen: ", ressource_availabilities)
    
    #Ordne jedem Job eine Priorität aus dem Genom zu
    genome_priority_list = genome.get_priorities()
    job_priorities = {}
    for i in range(len(genome_priority_list)):
        job_priorities[problem.jobs[i].jobnr] = genome_priority_list[i]

    #Ordne jedem Job seine Dauer und seine verwendeten ressourcen zu
    job_durations = {}
    job_ressources = {}
    for job in problem.jobs:
        job_durations[job.jobnr] = job.modes.duration
        job_ressources[job.jobnr] = job.modes.usedRessources
       # print("Dauer Job ",job.jobnr, ":",job.modes.duration)
        #print("Ressources Job ",job.jobnr, ":",job.modes.usedRessources,"\n")
    
    C = [problem.jobs[0].jobnr]
    #Berechne eine Menge aus allen Jobs nur nicht dem ersten Job
    C_Complement = []
    for i in range(1, problem.amountJobs):
        C_Complement.append(problem.jobs[i].jobnr)
    S_C = {problem.jobs[0].jobnr:0}

    for r in range(problem.amountJobs -1):
        Epsilon = _compute_epsilon(C,C_Complement,problem.jobs)
       # print("Epsilon: ", Epsilon)
        #Berechne den job in Epsilon mit hoechster Priorität
        highestPriority = job_priorities[Epsilon[0]]
        highestPriorityJob = Epsilon[0]
        for job in Epsilon:
            if job_priorities[job] < highestPriority:
                highestPriorityJob = job
                highestPriority = job_priorities[job]
        #print("Highest prioritie job:", highestPriorityJob)
        #print("Highest prioritie:", highestPriority)
        
        #Berechne den fruehstmoeglichen Startzeitpunkt vom Job mit der hoechsten Prioritaet
        predecessors = _compute_predecessors(highestPriorityJob, problem.jobs)
        #print("Predecessors: ", predecessors)
        ES = job_durations[predecessors[0]]+S_C[predecessors[0]]
        for predecessor in predecessors:
            predecessor_end_time = job_durations[predecessor]+S_C[predecessor]
            if ES < predecessor_end_time:
                ES = predecessor_end_time
        #print("Fruehester Startzeitpunkt: ", predecessor_end_time)
        #Berechne den fruehesten Zeitpunkt, zu dem alle benoetigten Ressourcen verfuegbar sind
        start_time = ES
        for t in range(ES, problem.timeHorizont):
            start_time = t
            if _are_ressources_available(t, job_durations[highestPriorityJob], job_ressources[highestPriorityJob], ressource_availabilities):
                break

        #print("Zeitpunkt mit verfuegbaren Ressourcen: ", start_time)
        #Aktualisiere Scedule und andere Mengen
        S_C[highestPriorityJob] = start_time
        C.append(highestPriorityJob)
        C_Complement.remove(highestPriorityJob)

        #Aktualisiere Ressourcenverfuegbarkeit
        for i in range(len(job_ressources[highestPriorityJob])):
            amount_used = job_ressources[highestPriorityJob][i]
            for availabilties in ressource_availabilities:
                for t in range(start_time, start_time+job_durations[highestPriorityJob]):
                    availabilties[t] -= amount_used
            
        
    return S_C
