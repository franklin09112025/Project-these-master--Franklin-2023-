import random
import Genome
from readInstancePSPLIB import *

#Diese Mutationsoperatoren funktionieren nur mit RandomVectorGenome

class RandomResettingMutationOperator:
    #Mutation rate gibt die Wahrscheinlichkeit an, dass eine Stelle des Genoms geaendert wird
    def __init__(self, mutation_rate):
         self.mutation_rate = mutation_rate

    def mutate(self, genome):
        random_vectors = []
        for i in range(len(genome.random_vectors)):
            if random.random()<self.mutation_rate:
                random_vectors.append(random.random())
            else:
                random_vectors.append(genome.random_vectors[i])
        return Genome.RandomVectorGenome(random_vectors)


class RandomSwapMutationOperator:
    #Mutation rate gibt die Wahrscheinlichkeit an, dass eine Stelle des Genoms geaendert wird
    def __init__(self, mutation_rate):
         self.mutation_rate = mutation_rate

    def mutate(self, genome):
     
        if random.random()<self.mutation_rate:
            activities = genome.activities
            randomIndex1 = random.randrange(len(activities))
            randomIndex2 = random.randrange(len(activities))
            activities[randomIndex1], activities[randomIndex2] = activities[randomIndex2], activities[randomIndex1]
            
            return Genome.ActivityListGenome(activities, genome.jobs)
        else:
            return Genome.ActivityListGenome(genome.activities, genome.jobs)


#Dieser Mutationsoperator funktioniert nur mit ActivityListGenome

class InsertMutationOperator:
    #Mutation rate gibt die Wahrscheinlichkeit an, dass eine Mutation durchgefuehrt wird
    def __init__(self, mutation_rate):
         self.mutation_rate = mutation_rate

    def mutate(self, genome):
        if random.random()<self.mutation_rate:
            new_activities = genome.activities
            random_element = new_activities.pop(random.randint(0, len(new_activities)-1))
            new_activities.insert(random.randint(0,len(new_activities)-1), random_element)
            return Genome.ActivityListGenome(new_activities, genome.jobs)
        else:
            return Genome.ActivityListGenome(genome.activities, genome.jobs)

