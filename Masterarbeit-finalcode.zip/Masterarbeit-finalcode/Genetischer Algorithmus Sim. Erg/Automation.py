import Configuration as conf
import csv
from readInstancePSPLIB import *
import SerielGenerationChema
import Genome
import random
import Mutations
import Crossover
import time
#Waehlt den Index eines Elterngenoms zufaellig aus. Die Wahrscheinlichkeit ist proportional zum fitness score
def roulette_wheel_selection(fitness_scores):
    #um auch negative fitness-scores zu ermoeglichen, wird das minimum aller scores von ihnen abgezogen
    min_fitness = min(fitness_scores)
    
    total_fitness_sum = 0
    for fitness in fitness_scores:
        total_fitness_sum += fitness - min_fitness

    random_value = random.random()*total_fitness_sum
    
    fitness_sum = 0
    for i in range(len(fitness_scores)):
        fitness_sum += fitness_scores[i]- min_fitness
        if random_value < fitness_sum:
            return i
    return len(fitness_scores)-1

class NegativeTimeFitnessFunction:
    def fitness(self, duration):
        return -duration


def compute_time(config, problem):
    start_time = time.time() 
    if config.mutation_operator == conf.MutationOperator.RANDOM_RESETTING:
        mutation_operator = Mutations.RandomResettingMutationOperator(config.mutation_rate)
    elif config.mutation_operator == conf.MutationOperator.RANDOM_SWAP:
        mutation_operator = Mutations.RandomSwapMutationOperator(config.mutation_rate)
    elif config.mutation_operator == conf.MutationOperator.INSERT:
        mutation_operator = Mutations.InsertMutationOperator(config.mutation_rate)

    if config.crossover_operator == conf.CrossoverOperator.UNIFORM:
        crossover_operator = Crossover.UniformCrossover(config.crossover_rate)
    elif config.crossover_operator == conf.CrossoverOperator.ONE_POINT:
        crossover_operator = Crossover.OnePointCrossover(config.crossover_rate)
    elif config.crossover_operator == conf.CrossoverOperator.PARTIALLY_MAPPED:
        crossover_operator = Crossover.PartiallyMappedCrossover(config.crossover_rate)

    
    fitness_function = NegativeTimeFitnessFunction()
    #initialisiere erste generation
    population = []
    for i in range(config.generation_size):
        if config.genome_type == conf.GenomeType.RANDOM_VECTOR:
            population.append(Genome.RandomVectorGenome.init_randomly(problem.amountJobs))
        elif config.genome_type == conf.GenomeType.ACTIVITY_LIST:
            population.append(Genome.ActivityListGenome.init_randomly(problem.jobs))
    for i in range(config.num_generations):
        #berechne fitness-score fuer jedes genom
        fitness_scores = []
        first_genome = True
        for genome in population:
            scedule = SerielGenerationChema.seriel_generation_chema(problem, genome)
            #die Zeit des letzten jobs ist die Zeitdauer
            duration = scedule[problem.amountJobs-1]
            #aktualisiere die beste Zeit der Generation
            if first_genome:
                best_time_of_generation = duration
                best_scedule_of_generation = scedule
                first_genome = False
            elif duration < best_time_of_generation:
                best_time_of_generation = duration
                best_scedule_of_generation = scedule
                        
            fitness = fitness_function.fitness(duration)
            fitness_scores.append(fitness)

            if i == 0:
                best_time_of_all = best_time_of_generation
                best_scedule_of_all = best_scedule_of_generation
            elif best_time_of_generation < best_time_of_all:
                best_time_of_all = best_time_of_generation
                best_scedule_of_all = best_scedule_of_generation    
        #berechne naechste Generation
        next_generation = []
        while len(next_generation) < config.generation_size:
            #selektiere eltern
            father = population[roulette_wheel_selection(fitness_scores)]
            mother = population[roulette_wheel_selection(fitness_scores)]
            child1, child2 = crossover_operator.crossover(father, mother)

            #mutiere Kinder
            child1 = mutation_operator.mutate(child1)
            child2 = mutation_operator.mutate(child2)

            next_generation.append(child1)
            next_generation.append(child2)
        population = next_generation
        elapsed_time = time.time() - start_time 
    return best_time_of_all , elapsed_time

def compare_configurations(configurations, filename, instance_names):
    with open(filename, 'w', newline='') as csvfile:
        spamwriter = csv.writer(csvfile, delimiter=';', quotechar='|', quoting=csv.QUOTE_MINIMAL)
        spamwriter.writerow(["Konfigurationen:"])
        spamwriter.writerow(["","Genomtyp", "Anzahl Generationen", "Generationsgröße", "Mutationsoperator","Mutationsrate", "Crossoveroperator", "Crossoverrate"])
        for config in configurations:
            config.write_to_csv(spamwriter)
        spamwriter.writerow([])
        spamwriter.writerow(["Ergebnisse:"])
        row = [""]
        for config in configurations:
            row.append(config.name)
        spamwriter.writerow(row)
        for instance_name in instance_names:
            row = [instance_name]
            problem = readFilePSPLIB(instance_name)
            print("Compute "+instance_name)
            for config in configurations:
                print(config.name)
                best_time, elapsed_time = compute_time(config, problem)
                row.append(best_time)
                row.append(f"{elapsed_time / 60:.2f} min") 
            spamwriter.writerow(row)
        print("Finished")
            

configurations = []

config = conf.Config(name="Config 1",
                     genome_type=conf.GenomeType.RANDOM_VECTOR,
                     num_generations= 50,
                     generation_size=50,
                     mutation_operator=conf.MutationOperator.RANDOM_RESETTING,
                     mutation_rate=0.05,
                     crossover_operator=conf.CrossoverOperator.UNIFORM,
                     crossover_rate=0.7)

configurations.append(config)

instance_names = []
base_path = "InstanzenPSPLIB\\"

for i in range(11, 61):  # assuming the range is from 11 to 60
    for j in range(1, 11):
        instance_names.append(f"{base_path}j120{i}_{j}.sm")
         
compare_configurations(configurations, "results.csv", instance_names)
