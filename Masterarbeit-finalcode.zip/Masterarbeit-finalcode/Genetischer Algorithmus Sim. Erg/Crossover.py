import random
import Genome
from readInstancePSPLIB import *

#Diese Crossover-Operatoren funktionieren nur mit RandomVector

class UniformCrossover:
    def __init__(self, crossover_rate):
        self.crossover_rate = crossover_rate

    def crossover(self, father, mother):

        if random.random() < self.crossover_rate:
            child_1_random_vectors = []
            child_2_random_vectors = []
        
            for i in range(len(father.random_vectors)):
                if random.random()<0.5:
                    child_1_random_vectors.append(father.random_vectors[i])
                    child_2_random_vectors.append(mother.random_vectors[i])
                else:
                    child_1_random_vectors.append(mother.random_vectors[i])
                    child_2_random_vectors.append(father.random_vectors[i])
            return Genome.RandomVectorGenome(child_1_random_vectors),Genome.RandomVectorGenome(child_2_random_vectors)
        else:
            return Genome.RandomVectorGenome(father.random_vectors), Genome.RandomVectorGenome(mother.random_vectors)

class OnePointCrossover:
    def __init__(self, crossover_rate):
         self.crossover_rate = crossover_rate

    def crossover(self, father, mother):

        if random.random() < self.crossover_rate:
            child_1_random_vectors = []
            child_2_random_vectors = []

            splitIndex = random.randrange(len(father.random_vectors))
            
            for i in range(len(father.random_vectors)):
                if i < splitIndex:
                    child_1_random_vectors.append(father.random_vectors[i])
                    child_2_random_vectors.append(mother.random_vectors[i])
                else:
                    child_1_random_vectors.append(mother.random_vectors[i])
                    child_2_random_vectors.append(father.random_vectors[i])
            return Genome.RandomVectorGenome(child_1_random_vectors),Genome.RandomVectorGenome(child_2_random_vectors)
        else:
            return Genome.RandomVectorGenome(father.random_vectors), Genome.RandomVectorGenome(mother.random_vectors)


#Dieser Crossover-Operator funktioniert nur mit ActivityList


class PartiallyMappedCrossover:
    def __init__(self, crossover_rate):
         self.crossover_rate = crossover_rate

    def crossover(self, father, mother):

        if random.random() < self.crossover_rate:
            child_1_activities = father.activities.copy()
            child_2_activities = mother.activities.copy()

            index_start = random.randint(0, len(child_1_activities)-1)
            index_end = random.randint(index_start, len(child_1_activities)-1)
            for i in range(index_start, index_end+1):
                activity_1 = father.activities[i]
                activity_2 = mother.activities[i]

                pos_activity_1 = child_1_activities.index(activity_1)
                pos_activity_2 = child_1_activities.index(activity_2)

                child_1_activities[pos_activity_1],child_1_activities[pos_activity_2] = child_1_activities[pos_activity_2],child_1_activities[pos_activity_1]

                pos_activity_1 = child_2_activities.index(activity_1)
                pos_activity_2 = child_2_activities.index(activity_2)

                child_2_activities[pos_activity_1],child_2_activities[pos_activity_2] = child_2_activities[pos_activity_2],child_2_activities[pos_activity_1]           

            return Genome.ActivityListGenome(child_1_activities, father.jobs),Genome.ActivityListGenome(child_2_activities, mother.jobs)
        else:
            return Genome.ActivityListGenome(father.activities, father.jobs), Genome.ActivityListGenome(mother.activities, mother.jobs)

