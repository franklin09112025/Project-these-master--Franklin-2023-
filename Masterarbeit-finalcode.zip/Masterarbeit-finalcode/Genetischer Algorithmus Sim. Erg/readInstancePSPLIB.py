import os
class Resources :
	def __init__(self, renewable):
            self.renewable = renewable 
    
class Mode :
    def __init__(self,jobnr,mode,duration,usedRessources):
        self.jobnr = jobnr
        self.mode = mode
        self.duration = duration
        self.usedRessources = usedRessources
        
class Job :
    def __init__(self,jobnr, modes, amountModes,amountSuccessors,successors,predecessors):
         self.jobnr = jobnr
         self.amountModes = amountModes
         self.amountSuccessors = amountSuccessors
         self.successors = successors
         self.predecessors = predecessors
         self.modes = modes
         
class Problem :
    def __init__(self,projects, amountJobs,dueDate,avaibleRessources,jobs,timeHorizont):
        self.projects = projects
        self.amountJobs = amountJobs
        self.dueDate = dueDate
        self.availableResources = avaibleRessources
        self.jobs = jobs
        self.timeHorizont = timeHorizont
        
def readFilePSPLIB(file):
    p = Problem(0,0,0,Resources([]),[],0)
    data_file_path = os.path.join(os.path.dirname(__file__), file)
    f = open(data_file_path)
    lines = f.readlines()
    #find the amountJobs
    for line in lines :
        if line.find("jobs") > -1 :
            p.amountJobs = int (line.split(":")[1])
            break
    for line in lines :
        if line.find("horizon") > -1 :
            p.timeHorizont = int (line.split(":")[1])
            break
    counter = 0
    for line in lines :
        if line.find("duedate") > -1 :
            p.dueDate  = int(lines[counter + 1].split()[3])
            break
        counter +=1
    counter =0 
    for line in lines :
        if line.find("PRECEDENCE RELATIONS") > -1 :
           for i in range(1,p.amountJobs+1):
                job = Job(0,0,0,0,[],set())
                linesplit  = lines[counter +1+ i].split()
                job.jobnr = int (linesplit[0])-1
                job.modes = int (linesplit[1])
                job.amountSuccessors = int (linesplit[2])
                for j in range(0,job.amountSuccessors):
                    job.successors.append(int(linesplit[j+3])-1)
                p.jobs.append(job)
           break
        counter+=1
    counter = 0
    for line in lines :
        if line.find("REQUESTS/DURATIONS") > -1 :
           for i in range(1,p.amountJobs+1):
                mode = Mode(0,0,0,[])
                linesplit  = lines[counter + 2 + i].split()
                mode.jobnr = int (linesplit[0])
                mode.mode = int (linesplit[1])
                mode.duration = int (linesplit[2])
                for j in range(0,4):
                    mode.usedRessources.append(int(linesplit[j+3]))
                p.jobs[i-1].modes = mode
           break
        counter+=1
    counter = 0
    for line in lines :
        if line.find("RESOURCEAVAILABILITIES:") > -1 :
                linesplit  = lines[counter + 2].split()
                for i in range(0,4):
                    p.availableResources.renewable.append(int(linesplit[i]))
                break
        counter+=1
    counter = 0
    #Update Job n+2
    p.jobs[p.amountJobs-1].amountSuccessor = 1
    p.jobs[p.amountJobs-1].successors.append(0) 
    p.jobs[p.amountJobs-1].modes.duration = 0
    #Vorgängen von jedem Job j abbilden
    for j in range(0, p.amountJobs):
        for i in range(0,p.amountJobs):
            if j in p.jobs[i].successors:
                p.jobs[j].predecessors.add(i)
    return p
